from torch_geometric.loader import DataLoader
from dataset_utils import *
import torch
import torch.nn.functional as F
from torch_geometric.nn.conv import SAGEConv, GCNConv, GATConv
from torch_geometric.nn.dense import Linear
from torch_geometric.nn.models import JumpingKnowledge
from torch_geometric.nn.pool import global_add_pool, global_max_pool, SAGPooling
from sklearn.model_selection import KFold  # 导入KFold
'''
torch_geometric.loader 中的 DataLoader 用于加载图数据。
dataset_utils 是用户自定义的模块，包含了生成和拆分数据集的函数。
torch 是 PyTorch 库，用于深度学习。
torch.nn.functional 包含一些常用的神经网络函数，如激活函数和损失函数。
torch_geometric.nn 包含了一些用于图神经网络的模块，如卷积层、线性层、跳跃知识网络（Jumping Knowledge）、全局池化层和层次池化层。
'''

'''
tar_idx 定义了当前要预测的目标变量的索引，这里是 3，对应 bram。
jknFlag 是一个标志，用于决定是否使用跳跃知识网络（Jumping Knowledge Network）。
'''
target = ['lut', 'ff', 'dsp', 'bram', 'uram', 'srl', 'cp', 'power']
tar_idx = 3
jknFlag = 0

def set_seed(seed):
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)  # 当前GPU
    torch.cuda.manual_seed_all(seed) #所有GPU

    np.random.seed(seed)
    random.seed(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.enabled = False

class HierNet(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels, num_layers, conv_type, hls_dim, drop_out=0.0, pool_ratio=0.5):
        super(HierNet, self).__init__()

        self.drop_out = drop_out
        self.pool_ratio = pool_ratio
        if conv_type == 'gcn':
            conv = GCNConv
        elif conv_type == 'gat':
            conv = GATConv
        elif conv_type == 'sage':
            conv = SAGEConv
        else:
            conv = GCNConv

        self.convs = torch.nn.ModuleList()
        self.pools = torch.nn.ModuleList()

        for i in range(num_layers):
            if i == 0:
                self.convs.append(conv(in_channels, hidden_channels))
            else:
                self.convs.append(conv(hidden_channels, hidden_channels))
            self.pools.append(SAGPooling(hidden_channels, self.pool_ratio))
        if jknFlag:
            self.jkn = JumpingKnowledge('lstm', channels=hidden_channels, num_layers=2)

        self.global_pool = global_add_pool
        self.channels = [hidden_channels * 2 + hls_dim, 64, 64, 1]
        self.mlps = torch.nn.ModuleList()

        for i in range(len(self.channels) - 1):
            fc = Linear(self.channels[i], self.channels[i + 1])
            self.mlps.append(fc)

    def forward(self, x, edge_index, batch, hls_attr):

        x = x.to(torch.float32)
        h_list = []

        for step in range(len(self.convs)):
            x = self.convs[step](x, edge_index)
            x = F.relu(x)
            x = F.dropout(x, p=self.drop_out, training=self.training)
            x, edge_index, _, batch, _, _ = self.pools[step](x, edge_index, None, batch, None)
            h = torch.cat([global_max_pool(x, batch), global_add_pool(x, batch)], dim=1)
            h_list.append(h)

        if jknFlag:
            x = self.jkn(h_list)
        x = h_list[0] + h_list[1] + h_list[2]
        x = torch.cat([x, hls_attr], dim=-1)

        for f in range(len(self.mlps)):
            if f < len(self.mlps) - 1:
                x = F.relu(self.mlps[f](x))
                x = F.dropout(x, p=self.drop_out, training=self.training)
            else:
                x = self.mlps[f](x)

        return x

def train(model, train_loader):
    model.train()
    '''total_mse 和 total_mae: 初始化总的均方误差（MSE）和平均绝对误差（MAE），用于累积每个批次的误差。'''
    total_mse = 0
    total_mae = 0
    '''遍历 train_loader 中的每个批次数据 data。data.to(device): 将数据移动到指定的设备（例如 GPU）。optimizer.zero_grad(): 清零优化器的梯度，以防止梯度累积'''
    for _, data in enumerate(train_loader):
        data = data.to(device)
        optimizer.zero_grad()
        hls_attr = data['hls_attr']
        '''model(data.x, data.edge_index, data.batch, hls_attr): 将节点特征 data.x、边索引 data.edge_index、批次索引 data.batch 和额外输入特征 hls_attr 输入模型，得到输出 out。'''
        out = model(data.x, data.edge_index, data.batch, hls_attr)
        out = out.view(-1)
        '''true_y: 从数据中提取真实标签 data['y'] 并转置，得到目标值。'''
        true_y = data['y'].t()
        '''mse: 计算预测值 out 和真实值 true_y[tar_idx] 之间的 Huber 损失。
        mae: 计算预测值 out 和真实值 true_y[tar_idx] 之间的平均绝对误差（L1 损失）。
        loss = mse: 将 Huber 损失作为总的损失进行反向传播。'''
        mse = F.huber_loss(out, true_y[tar_idx]).float()
        mae = F.l1_loss(out, true_y[tar_idx]).float()
        loss = mse
        '''loss.backward(): 反向传播，计算梯度。optimizer.step(): 根据计算的梯度更新模型的参数。'''
        loss.backward()
        optimizer.step()
        '''累积每个批次的 MSE 和 MAE，乘以该批次中图的数量（data.num_graphs），以便计算总的误差。'''
        total_mse += mse.item() * data.num_graphs
        total_mae += mae.item() * data.num_graphs
    '''ds: 获取训练数据集。将总的 MSE 和 MAE 除以数据集的大小，得到平均误差。'''
    ds = train_loader.dataset
    total_mse = total_mse / len(ds)
    total_mae = total_mae / len(ds)

    return total_mse, total_mae

'''该 test 函数用于评估给定的模型。它遍历测试数据加载器 loader，在每个批次的数据上执行前向传播，计算损失，但不会更新模型参数。'''
def test(model, loader, epoch):
    model.eval()
    '''model.eval(): 将模型设置为评估模式，这会禁用 Dropout 和 BatchNorm 等训练时的特殊操作。'''
    '''with torch.no_grad(): 禁用梯度计算，以减少内存消耗和计算时间，因为在测试阶段不需要反向传播。'''
    with torch.no_grad():
        '''初始化总的均方误差（MSE）和平均绝对误差（MAE）。y, y_hat, residual: 用于存储真实值、预测值和残差（真实值与预测值的差）。'''
        mse = 0
        mae = 0
        y = []
        y_hat = []
        residual = []
        for _, data in enumerate(loader):
            data = data.to(device)
            '''hls_attr: 从数据中提取额外的输入特征 hls_attr。
            model(data.x, data.edge_index, data.batch, hls_attr): 将节点特征 data.x、边索引 data.edge_index、批次索引 data.batch 和额外输入特征 hls_attr 输入模型，得到输出 out。
            out.view(-1): 将输出展平为一维向量。'''
            hls_attr = data['hls_attr']
            out = model(data.x, data.edge_index, data.batch, hls_attr)
            out = out.view(-1)
            '''true_y: 从数据中提取真实标签 data['y'] 并转置，得到目标值。计算预测值 out 和真实值 true_y[tar_idx] 之间的 Huber 损失（MSE）和平均绝对误差（MAE），并乘以该批次中图的数量（data.num_graphs）累积到总的 MSE 和 MAE'''
            true_y = data['y'].t()
            mse += F.huber_loss(out, true_y[tar_idx]).float().item() * data.num_graphs  # MSE
            mae += F.l1_loss(out, true_y[tar_idx]).float().item() * data.num_graphs  # MAE
            '''将当前批次的真实值、预测值和残差添加到 y, y_hat, residual 列表中。'''
            y.extend(true_y[tar_idx].cpu().numpy().tolist())
            y_hat.extend(out.cpu().detach().numpy().tolist())
            residual.extend((true_y[tar_idx] - out).cpu().detach().numpy().tolist())
        '''每 10 个 epoch 打印一次当前批次的预测值和真实值，方便调试和观察模型的预测效果。'''
        if epoch % 10 == 0:
            print('pred.y:', out)
            print('data.y:', true_y[tar_idx])
        '''获取测试数据集 ds。将总的 MSE 和 MAE 除以数据集的大小，得到平均误差。'''
        ds = loader.dataset
        mse = mse / len(ds)
        mae = mae / len(ds)
    return mse, mae

'''这段代码是一个用于训练和测试图神经网络（GNN）的完整脚本。它包括数据加载、模型训练、模型评估和模型保存。'''
if __name__ == "__main__":
    set_seed(128)
    batch_size = 32
    dataset_dir = os.path.abspath('../dataset/std')
    model_dir = os.path.abspath('./model')
    dataset = os.listdir(dataset_dir)
    dataset_list = generate_dataset(dataset_dir, dataset, print_info=True)

    print(f"Dataset loaded with {len(dataset_list)} graphs")

    kfold = KFold(n_splits=5, shuffle=True, random_state=128)  # 使用5折交叉验证
    # 用于存储每个fold的最小训练和测试MAE
    all_min_train_mae = []
    all_min_test_mae = []

    for fold, (train_idx, test_idx) in enumerate(kfold.split(dataset_list)):
        print(f"Fold {fold + 1}")
        # 使用KFold划分训练集和验证集
        train_ds = [dataset_list[i] for i in train_idx]
        test_ds = [dataset_list[i] for i in test_idx]

        train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, drop_last=True)
        test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=True, drop_last=True)

        # 初始化模型
        data_ini = None
        for step, data in enumerate(train_loader):
            if step == 0:
                data_ini = data
                break

        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        model = HierNet(in_channels=data_ini.num_features, hidden_channels=64, num_layers=3, conv_type='sage',
                        hls_dim=6, drop_out=0.0)
        model = model.to(device)
        print(model)

        LR = 0.01
        optimizer = torch.optim.Adam(model.parameters(), lr=LR, weight_decay=0.001)

        # 初始化每个fold的最小训练和测试MAE
        min_train_mae = float('inf')
        min_test_mae = float('inf')

        for epoch in range(500):
            train_loss, train_mae = train(model, train_loader)
            test_loss, test_mae = test(model, test_loader, epoch)
            print(f'Epoch: {epoch:03d}, Train Loss: {train_loss:.4f}, Test Loss: {test_loss:.4f}')
            print(f'Epoch: {epoch:03d}, Train MAE: {train_mae:.4f}, Test MAE: {test_mae:.4f}')

            if epoch % 10 == 0:
                for p in optimizer.param_groups:
                    p['lr'] *= 0.9

            if train_mae < min_train_mae:
                min_train_mae = train_mae
                # 保存最优训练模型
                torch.save({
                    'model': model.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    'epoch': epoch,
                    'min_train_mae': min_train_mae
                }, os.path.join(model_dir, f'{target[tar_idx]}_fold{fold + 1}_sage+gf_5z_mae_0.01_h64_checkpoint_train.pt'))

            if test_mae < min_test_mae:
                min_test_mae = test_mae
                # 保存最优测试模型
                torch.save({
                    'model': model.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    'epoch': epoch,
                    'min_test_mae': min_test_mae
                }, os.path.join(model_dir, f'{target[tar_idx]}_fold{fold + 1}_sage+gf_5z_mae_0.01_h64_checkpoint_test.pt'))

        print(f"Fold {fold + 1} Min Train MAE: {min_train_mae}")
        print(f"Fold {fold + 1} Min Test MAE: {min_test_mae}")
        # 保存每个fold的最小训练和测试MAE
        all_min_train_mae.append(min_train_mae)
        all_min_test_mae.append(min_test_mae)

    # 打印整个交叉验证的结果
    print("\nSummary of Cross-Validation:")
    for i in range(kfold.get_n_splits()):
        print(f"Fold {i + 1} - Min Train MAE: {all_min_train_mae[i]:.4f}, Min Test MAE: {all_min_test_mae[i]:.4f}")

    # 打印整个交叉验证的平均最小训练和测试MAE
    avg_min_train_mae = sum(all_min_train_mae) / len(all_min_train_mae)
    avg_min_test_mae = sum(all_min_test_mae) / len(all_min_test_mae)

    print(f"\nAverage Min Train MAE: {avg_min_train_mae:.4f}")
    print(f"Average Min Test MAE: {avg_min_test_mae:.4f}")









