from torch_geometric.loader import DataLoader
from dataset_utils import *
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn.conv import SAGEConv, GCNConv, GATConv,RGCNConv
from torch_geometric.nn.dense import Linear
from torch_geometric.nn.models import JumpingKnowledge
from torch_geometric.nn.pool import global_add_pool, global_max_pool, SAGPooling
import pandas as pd
import matplotlib.pyplot as plt

import random
import numpy as np
import os

target = ['lut', 'ff', 'dsp', 'bram', 'uram', 'srl', 'cp', 'power']
tar_idx = 1
jknFlag = 0

def add_edge_type_to_dataset(dataset_list):
    updated_dataset_list = []

    for data in dataset_list:
        # 检查是否存在 edge_attr 属性
        if 'edge_attr' in data:
            # 提取 edge_attr
            edge_attr = data.edge_attr

            # 创建 edge_type 张量
            edge_type = torch.zeros(edge_attr.size(0), dtype=torch.long)

            # 根据 edge_attr 第一列的值来分类边的类型
            edge_type[edge_attr[:, 0] == 0.0] = 0  # 如果第一列为0，edge_type设为0
            edge_type[edge_attr[:, 0] == 1.0] = 1  # 如果第一列为1，edge_type设为1
            edge_type[edge_attr[:, 0] == 4.0] = 2  # 如果第一列为4，edge_type设为2

            # 将 edge_type 添加到 data 对象中
            data.edge_type = edge_type

        # 将更新后的数据添加到 updated_dataset_list
        updated_dataset_list.append(data)

    return updated_dataset_list

def full_attention_conv(qs, ks, vs, output_attn=False, epsilon=1e-9):

    # normalize input 对 qs 和 ks 张量进行归一化处理，确保向量长度为1。这个步骤有助于稳定注意力分数的计算，使其不受输入尺度的影响。
    # qs = qs / torch.norm(qs, p=2) + epsilon # [N, H, M]
    # ks = ks / torch.norm(ks, p=2) + epsilon # [L, H, M]
    N = qs.shape[0]
    kvs = torch.einsum("lhm,lhd->hmd", ks, vs)
    attention_num = torch.einsum("nhm,hmd->nhd", qs, kvs)  # [N, H, D]
    attention_num += N * vs

    all_ones = torch.ones([ks.shape[0]]).to(ks.device)
    ks_sum = torch.einsum("lhm,l->hm", ks, all_ones)
    attention_normalizer = torch.einsum("nhm,hm->nh", qs, ks_sum)  # [N, H]


    attention_normalizer = torch.unsqueeze(
        attention_normalizer, len(attention_normalizer.shape)
    )  # [N, H, 1]
    attention_normalizer += torch.ones_like(attention_normalizer) * N
    attn_output = attention_num / attention_normalizer  # [N, H, D]


    if output_attn:
        attention = torch.einsum("nhm,lhm->nlh", qs, ks).mean(dim=-1)  # [N, N]
        normalizer = attention_normalizer.squeeze(dim=-1).mean(
            dim=-1, keepdims=True
        )  # [N,1]
        attention = attention / normalizer


    if output_attn:
        return attn_output, attention
    else:
        return attn_output



class TransConvLayer(torch.nn.Module):
    def __init__(self, in_channels, out_channels, num_heads=1, use_weight=True):
        super(TransConvLayer, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.num_heads = num_heads
        self.use_weight = use_weight

        # 为多头注意力定义 Wk, Wq, Wv
        self.Wk = Linear(in_channels, out_channels * num_heads, bias=False)
        self.Wq = Linear(in_channels, out_channels * num_heads, bias=False)
        if use_weight:
            self.Wv = Linear(in_channels, out_channels * num_heads, bias=False)

        # 用于多头投影
        self.head_proj = Linear(out_channels * num_heads, out_channels, bias=False)

    def forward(self, x, edge_index):
        row, col = edge_index
        x_out = torch.zeros_like(x)

        # 多头注意力机制
        query = self.Wq(x[row]).reshape(-1, self.num_heads, self.out_channels)
        key = self.Wk(x[col]).reshape(-1, self.num_heads, self.out_channels)
        if self.use_weight:
            value = self.Wv(x[col]).reshape(-1, self.num_heads, self.out_channels)
        else:
            value = x[col].reshape(-1, 1, self.out_channels)

        # 注意力计算
        attention_output = full_attention_conv(query, key, value)  # 计算注意力输出
        attn_output = attention_output.sum(dim=1)  # 聚合多头 sum

        # 累加到输出
        x_out[row] += attn_output

        # 投影回输出维度
        x_out = self.head_proj(x_out)
        return x_out


class TransConv(torch.nn.Module):
    def __init__(self, in_channels, out_channels, num_layers=1, num_heads=1,dropout=0.0, use_bn=True, use_residual=True):
        super(TransConv, self).__init__()
        self.convs = torch.nn.ModuleList()
        self.fcs = torch.nn.ModuleList()
        self.bns = torch.nn.ModuleList()
        self.fcs.append(Linear(in_channels, out_channels))
        for _ in range(num_layers):
            self.convs.append(TransConvLayer(out_channels, out_channels, num_heads))
            if use_bn:
                self.bns.append(torch.nn.LayerNorm(out_channels))

        self.dropout = dropout
        self.activation = F.relu
        self.use_bn = use_bn
        self.use_residual = use_residual
        self.alpha = nn.Parameter(torch.tensor(0.5))
    def reset_parameters(self):
        for conv in self.convs:
            conv.reset_parameters()
        for bn in self.bns:
            bn.reset_parameters()
        for fc in self.fcs:
            fc.reset_parameters()

    def forward(self,x,edge_index):
        x = self.fcs[0](x)
        if self.use_bn:
            x = self.bns[0](x)
        x = self.activation(x)
        x = F.dropout(x, p=self.dropout, training=self.training)
        layer_ = [x]

        for i, conv in enumerate(self.convs):
            x = conv(x, edge_index)  # 传递 edge_type
            if self.use_residual:
                x = self.alpha * x + (1 - self.alpha) * layer_[i]
            if self.use_bn:
                x = self.bns[i](x)
            x = self.activation(x)
            x = F.dropout(x, p=self.dropout, training=self.training)
            layer_.append(x)

        return x

    def get_attentions(self, x, edge_index):
        attentions = []
        layer_outputs = []

        x = self.fcs[0](x)
        if self.use_bn:
            x = self.bns[0](x)
        if self.activation:
            x = self.activation(x)

        layer_outputs.append(x)

        for i, conv in enumerate(self.convs):
            x, attn = conv(x, edge_index, output_attn=True)
            attentions.append(attn)
            if self.use_residual:
                x = self.alpha * x + (1 - self.alpha) * layer_outputs[i]
            if self.use_bn:
                x = self.bns[i + 1](x)
            layer_outputs.append(x)

        return torch.stack(attentions, dim=0)

class HierNet(torch.nn.Module):
    def __init__(self, in_channels, out_channels, num_layers,num_relations, graph_weight,use_graph,hls_dim, drop_out=0.0, pool_ratio=0.5):
        super(HierNet, self).__init__()

        self.drop_out = drop_out
        self.pool_ratio = pool_ratio
        self.use_graph = use_graph
        self.graph_weight = graph_weight


        self.convs = torch.nn.ModuleList()
        self.pools = torch.nn.ModuleList()

        for i in range(num_layers):
            if i == 0:
                self.convs.append(
                    RGCNConv(in_channels=in_channels, out_channels=out_channels, num_relations=num_relations))
            elif i == 1:
                self.convs.append(RGCNConv(in_channels=out_channels, out_channels=out_channels,
                                           num_relations=num_relations))
            elif i == 2:
                self.convs.append(RGCNConv(in_channels=out_channels, out_channels=out_channels,
                                           num_relations=num_relations))


        self.global_pool = global_add_pool
        self.trans_conv = TransConv(in_channels, out_channels, num_layers=1,
                                    dropout=drop_out)
        self.channels = [out_channels * 1 + hls_dim, 64, 64, 1]
        self.mlps = torch.nn.ModuleList()

        for i in range(len(self.channels) - 1):
            fc = Linear(self.channels[i], self.channels[i + 1])
            self.mlps.append(fc)

    def forward(self, x, edge_index,edge_type,  batch, hls_attr):

        x = x.to(torch.float32)
        # 全局注意力机制
        trans_x = self.trans_conv(x, edge_index)

        for step in range(len(self.convs)):
            x = self.convs[step](x, edge_index,edge_type)
            x = F.relu(x)
            x = F.dropout(x, p=self.drop_out, training=self.training)

        if self.use_graph:
            x = self.graph_weight * x + (1 - self.graph_weight) * trans_x
        else:
            x = trans_x
        # 全局j加池化
        h = self.global_pool(x, batch)

        # 拼接额外输入特征
        x = torch.cat([h, hls_attr], dim=-1)

        for f in range(len(self.mlps)):
            if f < len(self.mlps) - 1:
                x = F.relu(self.mlps[f](x))
                x = F.dropout(x, p=self.drop_out, training=self.training)
            else:
                x = self.mlps[f](x)

        return x



def train(model, train_loader):
    model.train()
    total_mse = 0
    total_mape = 0
    for _, data in enumerate(train_loader):
        data = data.to(device)
        optimizer.zero_grad()
        hls_attr = data['hls_attr']
        edge_type = data['edge_type']
        out = model(data.x, data.edge_index, edge_type, data.batch, hls_attr)
        out = out.view(-1)
        true_y = data['y'].t()
        mse = F.huber_loss(out, true_y[tar_idx]).float()
        mape = mape_loss(out, true_y[tar_idx]).float()
        loss = mse
        loss.backward()
        optimizer.step()
        total_mse += mse.item() * data.num_graphs
        total_mape += mape.item() * data.num_graphs
    ds = train_loader.dataset
    total_mse = total_mse / len(ds)
    total_mape = total_mape / len(ds)

    return total_mse, total_mape


def test(model, loader, epoch):
    model.eval()
    with torch.no_grad():
        mse = 0
        mape = 0
        y = []
        y_hat = []
        residual = []
        for _, data in enumerate(loader):
            data = data.to(device)
            hls_attr = data['hls_attr']
            edge_type = data['edge_type']
            out = model(data.x, data.edge_index, edge_type, data.batch, hls_attr)
            out = out.view(-1)
            true_y = data['y'].t()
            mse += F.huber_loss(out, true_y[tar_idx]).float().item() * data.num_graphs  # MSE
            mape += mape_loss(out, true_y[tar_idx]).float().item() * data.num_graphs  # MAPE
            y.extend(true_y[tar_idx].cpu().numpy().tolist())
            y_hat.extend(out.cpu().detach().numpy().tolist())
            residual.extend((true_y[tar_idx] - out).cpu().detach().numpy().tolist())
        if epoch % 10 == 0:
            print('pred.y:', out)
            print('data.y:', true_y[tar_idx])
        ds = loader.dataset
        mse = mse / len(ds)
        mape = mape / len(ds)
    return mse, mape


if __name__ == "__main__":
    batch_size = 32
    dataset_dir = os.path.abspath('../dataset/std')
    model_dir = os.path.abspath('./model')
    dataset = os.listdir(dataset_dir)
    dataset_list = generate_dataset(dataset_dir, dataset, print_info=False)
    updated_dataset_list = add_edge_type_to_dataset(dataset_list)
    train_ds, test_ds = split_dataset(updated_dataset_list, shuffle=True, seed=128)
    print('train_ds size = {}, test_ds size = {}'.format(len(train_ds), len(test_ds)))

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, drop_last=True)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=True, drop_last=True)

    data_ini = None
    for step, data in enumerate(train_loader):
        if step == 0:
            data_ini = data
            break

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = HierNet(in_channels=data_ini.num_features,use_graph=True,graph_weight=0.59, out_channels=128, num_layers=3,
                    hls_dim=6, drop_out=0.0,num_relations=3)
    model = model.to(device)
    print(model)

    LR = 0.005
    optimizer = torch.optim.Adam(model.parameters(), lr=LR, weight_decay=0.001)
    # scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer, gamma=0.9, last_epoch=-1)

    min_train_mape = 1
    min_test_mape = 1
    best_y = []
    best_y_hat = []
    for epoch in range(500):
        train_loss, train_mape = train(model, train_loader)
        test_loss, test_mape = test(model, test_loader, epoch)
        print(f'Epoch: {epoch:03d}, Train Loss: {train_loss:.4f}, Test Loss: {test_loss:.4f}')
        print(f'Epoch: {epoch:03d}, Train MAPE: {train_mape:.4f}, Test MAPE: {test_mape:.4f}')

        if epoch % 10 == 0:
            # scheduler.step()
            for p in optimizer.param_groups:
                p['lr'] *= 0.9

        save_train = False
        if train_mape < min_train_mape:
            min_train_mape = train_mape
            save_train = True


        save_test = False
        if test_mape < min_test_mape:
            min_test_mape = test_mape
            save_test = True
        checkpoint_1 = {
            'model': model.state_dict(),
            'optimizer': optimizer.state_dict(),
            'epoch': epoch,
            'min_train_mape': min_train_mape
        }

        checkpoint_2 = {
            'model': model.state_dict(),
            'optimizer': optimizer.state_dict(),
            'epoch': epoch,
            'min_test_mape': min_test_mape
        }

        if save_train:
            torch.save(checkpoint_1, os.path.join(model_dir, target[tar_idx] + '_sgformer_rgcn+gf_h64_d1_checkpoint_train.pt'))

        if save_test:
            torch.save(checkpoint_2, os.path.join(model_dir, target[tar_idx] + '_sgformer_rgcn+gf_h64_d1_checkpoint_test.pt'))

    print('Min Train MAPE: ' + str(min_train_mape))
    print('Min Test MAPE: ' + str(min_test_mape))
