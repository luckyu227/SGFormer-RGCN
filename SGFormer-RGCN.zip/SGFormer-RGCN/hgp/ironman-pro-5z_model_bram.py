import torch.nn.functional as F
from torch_geometric.nn.conv import GCNConv
from torch_geometric.nn.dense import Linear
from torch_geometric.nn.pool import global_mean_pool
from torch_geometric.loader import DataLoader
from dataset_utils import *
from sklearn.model_selection import KFold  # 导入KFold

def set_seed(seed):
    os.environ['PYTHONHASHSEED'] = str(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed(seed)  # 当前GPU
    torch.cuda.manual_seed_all(seed) #所有GPU

    np.random.seed(seed)
    random.seed(seed)

    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    torch.backends.cudnn.enabled = False

class GCNNet(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels=None, num_layers=2, drop_out=0.1):
        super(GCNNet, self).__init__()

        if hidden_channels is None:
            hidden_channels = [64, 128]
        self.drop_out = drop_out
        self.convs = torch.nn.ModuleList()

        for i in range(num_layers):
            if i == 0:
                self.convs.append(GCNConv(in_channels, hidden_channels[i]))
            else:
                self.convs.append(GCNConv(hidden_channels[i - 1], hidden_channels[i]))

        self.global_pool = global_mean_pool
        self.channels = [128, 64, 64, 64, 1]
        self.mlps = torch.nn.ModuleList()

        for i in range(len(self.channels) - 1):
            fc = Linear(self.channels[i], self.channels[i + 1])
            self.mlps.append(fc)

    def forward(self, x, edge_index, batch):

        x = x.to(torch.float32)

        for idx in range(len(self.convs)):
            x = self.convs[idx](x, edge_index)
            x = F.relu(x)
            x = F.dropout(x, p=0.0, training=self.training)

        x = self.global_pool(x, batch)

        for f in range(len(self.mlps)):
            if f < len(self.mlps) - 1:
                if f == 0:
                    x = F.leaky_relu(self.mlps[f](x), negative_slope=0.2)
                else:
                    x = F.leaky_relu(self.mlps[f](x), negative_slope=0.1)
                x = F.dropout(x, p=self.drop_out, training=self.training)
            else:
                x = self.mlps[f](x)
                x = F.relu(x)

        return x


target = ['lut', 'ff', 'dsp', 'bram', 'uram', 'srl', 'cp', 'power']
tar_idx = 3


def train(model, train_loader):
    model.train()
    total_mse = 0
    total_mae = 0
    for _, data in enumerate(train_loader):
        data = data.to(device)
        optimizer.zero_grad()
        out = model(data.x, data.edge_index, data.batch)
        out = out.view(-1)
        true_y = data['y'].t()
        mse = msle_loss(out, true_y[tar_idx]).float()  # MSLE for DSP
        mae = F.l1_loss(out, true_y[tar_idx]).float()  # MAE
        loss = mse
        loss.backward()
        optimizer.step()
        total_mse += mse.item() * data.num_graphs
        total_mae += mae.item() * data.num_graphs
    ds = train_loader.dataset
    total_mse = total_mse / len(ds)
    total_mae = total_mae / len(ds)
    return total_mse, total_mae


def test(model, loader, epoch):
    model.eval()
    with torch.no_grad():
        mse = 0
        mae = 0
        y = []
        y_hat = []
        residual = []
        for _, data in enumerate(loader):
            data = data.to(device)
            out = model(data.x, data.edge_index, data.batch)
            out = out.view(-1)
            true_y = data['y'].t()
            mse += msle_loss(out, true_y[tar_idx]).float().item() * data.num_graphs  # MSLE for DSP
            mae += F.l1_loss(out, true_y[tar_idx]).float().item() * data.num_graphs  # MAE
            y.extend(true_y[tar_idx].cpu().numpy().tolist())
            y_hat.extend(out.cpu().detach().numpy().tolist())
            residual.extend((true_y[tar_idx] - out).cpu().detach().numpy().tolist())
        if epoch % 10 == 0:
            print('pred.y:', out)
            print('data.y:', true_y[tar_idx])
        ds = loader.dataset
        mse = mse / len(ds)
        mae = mae / len(ds)
    return mse, mae


if __name__ == "__main__":
    set_seed(128)
    batch_size = 32
    dataset_dir = os.path.abspath('../../dataset/std')
    model_dir = './model'

    dataset = os.listdir(dataset_dir)
    dataset_list = generate_dataset(dataset_dir, dataset, print_info=False)
    print(f"Dataset loaded with {len(dataset_list)} graphs")

    kfold = KFold(n_splits=5, shuffle=True, random_state=128)  # 使用5折交叉验证
    # 用于存储每个fold的最小训练和测试MAE
    all_min_train_mae = []
    all_min_test_mae = []

    for fold, (train_idx, test_idx) in enumerate(kfold.split(dataset_list)):
        print(f"Fold {fold + 1}")
        # 使用KFold划分训练集和验证集
        train_ds = [dataset_list[i] for i in train_idx]
        test_ds = [dataset_list[i] for i in test_idx]

        train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, drop_last=True)
        test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=True, drop_last=True)

        # 初始化模型
        data_ini = None
        for step, data in enumerate(train_loader):
            if step == 0:
                data_ini = data
                break

        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        model = GCNNet(in_channels=data_ini.num_features)
        model = model.to(device)

        optimizer = torch.optim.Adam(model.parameters(), lr=0.01, weight_decay=0.001)
        scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer, gamma=0.9, last_epoch=-1)

        # 初始化每个fold的最小训练和测试MAE
        min_train_mae = float('inf')
        min_test_mae = float('inf')

        for epoch in range(500):
            train_loss, train_mae = train(model, train_loader)
            test_loss, test_mae = test(model, test_loader, epoch)
            print(f'Epoch: {epoch:03d}, Train Loss: {train_loss:.4f}, Test Loss: {test_loss:.4f}')
            print(f'Epoch: {epoch:03d}, Train MAE: {train_mae:.4f}, Test MAE: {test_mae:.4f}')

            if epoch % 10 == 0:
                for p in optimizer.param_groups:
                    p['lr'] *= 0.9

            if train_mae < min_train_mae:
                min_train_mae = train_mae
                # 保存最优训练模型
                torch.save({
                    'model': model.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    'epoch': epoch,
                    'min_train_mae': min_train_mae
                    }, os.path.join(model_dir,f'{target[tar_idx]}_fold{fold + 1}_ironman-pro_5z_mae_0.01_h64_checkpoint_train.pt'))

            if test_mae < min_test_mae:
                min_test_mae = test_mae
                # 保存最优测试模型
                torch.save({
                    'model': model.state_dict(),
                    'optimizer': optimizer.state_dict(),
                    'epoch': epoch,
                    'min_test_mae': min_test_mae
                }, os.path.join(model_dir, f'{target[tar_idx]}_fold{fold + 1}_ironman-pro_5z_mae_0.01_h64_checkpoint_test.pt'))

        print(f"Fold {fold + 1} Min Train MAE: {min_train_mae}")
        print(f"Fold {fold + 1} Min Test MAE: {min_test_mae}")
        # 保存每个fold的最小训练和测试MAE
        all_min_train_mae.append(min_train_mae)
        all_min_test_mae.append(min_test_mae)

    # 打印整个交叉验证的结果
    print("\nSummary of Cross-Validation:")
    for i in range(kfold.get_n_splits()):
        print(f"Fold {i + 1} - Min Train MAE: {all_min_train_mae[i]:.4f}, Min Test MAE: {all_min_test_mae[i]:.4f}")

    # 打印整个交叉验证的平均最小训练和测试MAE
    avg_min_train_mae = sum(all_min_train_mae) / len(all_min_train_mae)
    avg_min_test_mae = sum(all_min_test_mae) / len(all_min_test_mae)

    print(f"\nAverage Min Train MAE: {avg_min_train_mae:.4f}")
    print(f"Average Min Test MAE: {avg_min_test_mae:.4f}")

